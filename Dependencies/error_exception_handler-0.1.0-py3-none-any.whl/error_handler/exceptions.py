"""Minimal set of concrete exception subclasses."""

from __future__ import annotations

from typing import Any, Optional

from .base_exception import BaseAppException


class ValidationException(BaseAppException):
    def __init__(
        self,
        message: str = "Validation error",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            message,
            code="VALIDATION_ERROR",
            status_code=400,
            details=details,
            previous=previous,
        )


class NotFoundException(BaseAppException):
    def __init__(
        self,
        message: str = "Resource not found",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            message,
            code="NOT_FOUND",
            status_code=404,
            details=details,
            previous=previous,
        )


class UnauthorizedException(BaseAppException):
    def __init__(
        self,
        message: str = "Unauthorized",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            message,
            code="UNAUTHORIZED",
            status_code=401,
            details=details,
            previous=previous,
        )


class ForbiddenException(BaseAppException):
    def __init__(
        self,
        message: str = "Forbidden",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            message,
            code="FORBIDDEN",
            status_code=403,
            details=details,
            previous=previous,
        )


class ConflictException(BaseAppException):
    def __init__(
        self,
        message: str = "Conflict",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            message,
            code="CONFLICT",
            status_code=409,
            details=details,
            previous=previous,
        )


class InternalException(BaseAppException):
    def __init__(
        self,
        message: str = "Internal server error",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            message,
            code="INTERNAL_ERROR",
            status_code=500,
            details=details,
            previous=previous,
        )
