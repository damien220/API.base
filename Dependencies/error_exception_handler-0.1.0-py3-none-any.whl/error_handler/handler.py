"""ErrorHandler — single entry point for normalising and formatting errors."""

from __future__ import annotations

from .base_exception import BaseAppException
from .exceptions import InternalException
from .formatter import ErrorFormatter
from .types import HandlerResult


class ErrorHandler:
    """Central handler that accepts any raised value and returns a
    structured HandlerResult with status_code and formatted body."""

    @staticmethod
    def handle(error: BaseAppException | Exception) -> HandlerResult:
        """Normalise *error* and return a HandlerResult dict."""
        if not isinstance(error, BaseAppException):
            error = InternalException(
                message=str(error) or "An unexpected error occurred",
                previous=error,
            )

        body = ErrorFormatter.format(error)

        return {
            "status_code": error.status_code,
            "body": body,
        }
