"""ErrorFormatter — produces the consistent error structure."""

from __future__ import annotations

from .base_exception import BaseAppException
from .exceptions import InternalException
from .types import ErrorResponse


class ErrorFormatter:
    """Transforms any exception into a standardised ErrorResponse dict."""

    @staticmethod
    def format(error: BaseAppException | Exception) -> ErrorResponse:
        """Return a consistent ErrorResponse dict for any error.

        Non-BaseAppException errors are wrapped in an InternalException first.
        """
        if not isinstance(error, BaseAppException):
            error = InternalException(
                message=str(error) or "An unexpected error occurred",
                previous=error,
            )

        return error.to_dict()
