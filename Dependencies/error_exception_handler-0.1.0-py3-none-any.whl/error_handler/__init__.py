"""error_handler — abstract, reusable error and exception handling package."""

from .base_exception import BaseAppException
from .exceptions import (
    ConflictException,
    ForbiddenException,
    InternalException,
    NotFoundException,
    UnauthorizedException,
    ValidationException,
)
from .formatter import ErrorFormatter
from .handler import ErrorHandler
from .types import ErrorDetail, ErrorResponse, HandlerResult

__all__ = [
    "BaseAppException",
    "ConflictException",
    "ErrorDetail",
    "ErrorFormatter",
    "ErrorHandler",
    "ErrorResponse",
    "ForbiddenException",
    "HandlerResult",
    "InternalException",
    "NotFoundException",
    "UnauthorizedException",
    "ValidationException",
]
