"""Shared type definitions for the error_handler package."""

from __future__ import annotations

from typing import Any, Optional, TypedDict


class ErrorDetail(TypedDict):
    """Inner error structure."""

    code: str
    message: str
    details: Optional[dict[str, Any]]
    status_code: int


class ErrorResponse(TypedDict):
    """Top-level error response returned by the formatter and handler."""

    success: bool
    error: ErrorDetail


class HandlerResult(TypedDict):
    """Return type of ErrorHandler.handle()."""

    status_code: int
    body: ErrorResponse
