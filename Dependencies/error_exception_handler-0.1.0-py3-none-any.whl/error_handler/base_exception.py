"""Centralized base exception class for the package."""

from __future__ import annotations

from typing import Any, Optional


class BaseAppException(Exception):
    """Root exception that all application errors should extend.

    Provides a consistent structure with machine-readable code,
    numeric status, optional metadata, and cause chaining.
    """

    def __init__(
        self,
        message: str = "An unexpected error occurred",
        *,
        code: str = "INTERNAL_ERROR",
        status_code: int = 500,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.code = code
        self.status_code = status_code
        self.details = details
        self.previous = previous

        if previous is not None:
            self.__cause__ = previous

    def to_dict(self) -> dict[str, Any]:
        """Return the consistent error structure as a dict."""
        return {
            "success": False,
            "error": {
                "code": self.code,
                "message": self.message,
                "details": self.details,
                "status_code": self.status_code,
            },
        }
