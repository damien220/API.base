"""Cache-specific exception hierarchy.

Extends ``BaseAppException`` from the Error-Exception_Handler package when
available, otherwise falls back to plain ``Exception``.
"""

from __future__ import annotations

from typing import Any, Optional

try:
    from error_handler import BaseAppException
except ImportError:  # pragma: no cover

    class BaseAppException(Exception):  # type: ignore[no-redef]
        """Minimal stand-in when error_handler is not installed."""

        def __init__(
            self,
            message: str = "An unexpected error occurred",
            *,
            code: str = "INTERNAL_ERROR",
            status_code: int = 500,
            details: Optional[dict[str, Any]] = None,
            previous: Optional[Exception] = None,
        ) -> None:
            super().__init__(message)
            self.message = message
            self.code = code
            self.status_code = status_code
            self.details = details
            self.previous = previous
            if previous is not None:
                self.__cause__ = previous


class CacheException(BaseAppException):
    """Base for all cache errors."""

    def __init__(
        self,
        message: str = "Cache error",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(
            message,
            code="CACHE_ERROR",
            status_code=500,
            details=details,
            previous=previous,
        )


class CacheConnectionError(CacheException):
    """Backend is unreachable or failed to connect."""

    def __init__(
        self,
        message: str = "Cache backend connection failed",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(message, details=details, previous=previous)
        self.code = "CACHE_CONNECTION_ERROR"
        self.status_code = 503


class CacheSerializationError(CacheException):
    """Value cannot be serialized or deserialized."""

    def __init__(
        self,
        message: str = "Cache serialization failed",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(message, details=details, previous=previous)
        self.code = "CACHE_SERIALIZATION_ERROR"
        self.status_code = 500


class CacheKeyError(CacheException):
    """Invalid key format (empty, too long, illegal characters)."""

    def __init__(
        self,
        message: str = "Invalid cache key",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(message, details=details, previous=previous)
        self.code = "CACHE_KEY_ERROR"
        self.status_code = 400


class CacheBackendError(CacheException):
    """Backend-specific operation failed."""

    def __init__(
        self,
        message: str = "Cache backend error",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(message, details=details, previous=previous)
        self.code = "CACHE_BACKEND_ERROR"
        self.status_code = 500


class CacheCapacityError(CacheException):
    """Cache is full and eviction cannot free space."""

    def __init__(
        self,
        message: str = "Cache capacity exceeded",
        *,
        details: Optional[dict[str, Any]] = None,
        previous: Optional[Exception] = None,
    ) -> None:
        super().__init__(message, details=details, previous=previous)
        self.code = "CACHE_CAPACITY_ERROR"
        self.status_code = 507
