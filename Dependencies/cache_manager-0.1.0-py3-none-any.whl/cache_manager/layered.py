"""Multi-layer cache — L1 memory + L2 persistent with automatic promotion."""

from __future__ import annotations

from typing import Any, Optional

from .base import AbstractCache
from .types import CacheStats


class LayeredCache(AbstractCache):
    """Chain multiple cache backends (e.g. memory in front of Redis).

    On ``get``:
      - Checks layers in order (L1 first).
      - On miss from L1 but hit from L2+, promotes the value to all
        preceding layers so the next read is fast.

    On ``set`` / ``delete`` / ``clear``:
      - Propagates to **all** layers.

    Args:
        layers: Ordered list of cache backends (L1 = index 0).
        layer_ttls: Optional per-layer TTL overrides.  Index ``i``
            sets the TTL used when promoting into ``layers[i]``.
            ``None`` entries mean "use the value's original TTL".
    """

    def __init__(
        self,
        layers: list[AbstractCache],
        layer_ttls: Optional[list[Optional[int]]] = None,
    ) -> None:
        if not layers:
            raise ValueError("LayeredCache requires at least one layer")
        self._layers = layers
        self._layer_ttls = layer_ttls or [None] * len(layers)

    # --- Core CRUD ---

    def get(self, key: str, default: Any = None) -> Any:
        for i, layer in enumerate(self._layers):
            value = layer.get(key)
            if value is not None:
                # Promote to all preceding (faster) layers.
                for j in range(i):
                    ttl = self._layer_ttls[j]
                    self._layers[j].set(key, value, ttl=ttl)
                return value
        return default

    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        for i, layer in enumerate(self._layers):
            effective_ttl = self._layer_ttls[i] if self._layer_ttls[i] is not None else ttl
            layer.set(key, value, ttl=effective_ttl)

    def delete(self, key: str) -> bool:
        deleted = False
        for layer in self._layers:
            if layer.delete(key):
                deleted = True
        return deleted

    def exists(self, key: str) -> bool:
        return any(layer.exists(key) for layer in self._layers)

    def clear(self, namespace: Optional[str] = None) -> int:
        total = 0
        for layer in self._layers:
            total += layer.clear(namespace=namespace)
        return total

    # --- Batch ---

    def get_many(self, keys: list[str]) -> dict[str, Any]:
        found: dict[str, Any] = {}
        remaining = list(keys)
        for i, layer in enumerate(self._layers):
            if not remaining:
                break
            results = layer.get_many(remaining)
            # Promote hits to faster layers.
            for k, v in results.items():
                for j in range(i):
                    ttl = self._layer_ttls[j]
                    self._layers[j].set(k, v, ttl=ttl)
            found.update(results)
            remaining = [k for k in remaining if k not in results]
        return found

    def set_many(self, mapping: dict[str, Any], ttl: Optional[int] = None) -> None:
        for i, layer in enumerate(self._layers):
            effective_ttl = self._layer_ttls[i] if self._layer_ttls[i] is not None else ttl
            layer.set_many(mapping, ttl=effective_ttl)

    def delete_many(self, keys: list[str]) -> int:
        deleted = 0
        seen: set[str] = set()
        for layer in self._layers:
            for k in keys:
                if k not in seen and layer.delete(k):
                    seen.add(k)
                    deleted += 1
                elif k in seen:
                    layer.delete(k)  # propagate to remaining layers
        return deleted

    # --- Stats / lifecycle ---

    def get_stats(self) -> CacheStats:
        """Aggregate stats from the first (L1) layer."""
        return self._layers[0].get_stats()

    def connect(self, config: dict[str, Any] | None = None) -> None:
        for layer in self._layers:
            layer.connect(config)

    def disconnect(self) -> None:
        for layer in self._layers:
            layer.disconnect()
