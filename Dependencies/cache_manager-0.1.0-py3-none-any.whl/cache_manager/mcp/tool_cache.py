"""@tool_cache decorator — caches MCP tool-call results."""

from __future__ import annotations

import asyncio
import functools
import hashlib
import json
from typing import Any, Callable, Optional

from ..base import AbstractCache


def _build_tool_key(name: str, arguments: dict[str, Any], prefix: str) -> str:
    """Deterministic key from tool name + sorted arguments."""
    canonical = json.dumps(
        {"tool": name, "args": arguments},
        sort_keys=True,
        ensure_ascii=True,
        default=str,
    )
    digest = hashlib.sha256(canonical.encode()).hexdigest()
    return f"{prefix}:{digest}"


def tool_cache(
    cache: AbstractCache,
    ttl: Optional[int] = 300,
    namespace: str = "mcp_tool",
    ttl_map: Optional[dict[str, int]] = None,
    never_cache: Optional[set[str]] = None,
) -> Callable:
    """Decorator that caches MCP tool-call results.

    The decorated function must accept ``(name: str, arguments: dict)``
    as its first two positional arguments (or keyword arguments).

    Args:
        cache: Cache backend.
        ttl: Default TTL in seconds.
        namespace: Key prefix.
        ttl_map: Per-tool TTL overrides, e.g.
            ``{"web_search": 60, "db_query": 300}``.
        never_cache: Set of tool names that should never be cached.

    Supports both sync and async decorated functions.

    Example::

        @tool_cache(cache=my_cache, ttl=300)
        async def handle_tool(name: str, arguments: dict) -> dict:
            ...
    """
    _ttl_map = ttl_map or {}
    _never_cache = never_cache or set()

    def _resolve_ttl(tool_name: str) -> Optional[int]:
        return _ttl_map.get(tool_name, ttl)

    def decorator(func: Callable) -> Callable:
        if asyncio.iscoroutinefunction(func):
            @functools.wraps(func)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                name, arguments = _extract_name_args(args, kwargs)
                if name in _never_cache:
                    return await func(*args, **kwargs)

                key = _build_tool_key(name, arguments, namespace)
                cached = cache.get(key)
                if cached is not None:
                    return cached

                result = await func(*args, **kwargs)
                cache.set(key, result, ttl=_resolve_ttl(name))
                return result

            async_wrapper.cache = cache  # type: ignore[attr-defined]
            return async_wrapper
        else:
            @functools.wraps(func)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                name, arguments = _extract_name_args(args, kwargs)
                if name in _never_cache:
                    return func(*args, **kwargs)

                key = _build_tool_key(name, arguments, namespace)
                cached = cache.get(key)
                if cached is not None:
                    return cached

                result = func(*args, **kwargs)
                cache.set(key, result, ttl=_resolve_ttl(name))
                return result

            sync_wrapper.cache = cache  # type: ignore[attr-defined]
            return sync_wrapper

    return decorator


def _extract_name_args(
    args: tuple, kwargs: dict[str, Any]
) -> tuple[str, dict[str, Any]]:
    """Pull ``name`` and ``arguments`` from positional/keyword args."""
    name = kwargs.get("name", args[0] if len(args) > 0 else "")
    arguments = kwargs.get("arguments", args[1] if len(args) > 1 else {})
    return str(name), dict(arguments)
