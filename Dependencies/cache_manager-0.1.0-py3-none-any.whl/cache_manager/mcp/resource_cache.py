"""ResourceCache — caches MCP resource content with conditional refresh."""

from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Optional


from ..base import AbstractCache


@dataclass
class CachedResource:
    """Stored representation of a fetched MCP resource."""

    uri: str
    content: Any
    etag: Optional[str] = None
    last_modified: Optional[float] = None
    fetched_at: float = field(default_factory=time.time)


# Type alias for the fetch callback.
FetchFunc = Callable[..., Any]


class ResourceCache:
    """Cache MCP resource content with ETag / last-modified awareness.

    Args:
        cache: Underlying cache backend.
        default_ttl: Default staleness tolerance in seconds.
        ttl_map: Per-URI-prefix TTL overrides, e.g.
            ``{"file://": 3600, "https://api": 60}``.
        namespace: Cache key prefix.
    """

    def __init__(
        self,
        cache: AbstractCache,
        default_ttl: Optional[int] = 300,
        ttl_map: Optional[dict[str, int]] = None,
        namespace: str = "mcp_resource",
    ) -> None:
        self._cache = cache
        self._default_ttl = default_ttl
        self._ttl_map = ttl_map or {}
        self._namespace = namespace

    def _key(self, uri: str) -> str:
        digest = hashlib.sha256(uri.encode()).hexdigest()
        return f"{self._namespace}:{digest}"

    def _resolve_ttl(self, uri: str) -> Optional[int]:
        for prefix, ttl in self._ttl_map.items():
            if uri.startswith(prefix):
                return ttl
        return self._default_ttl

    # --- Sync API ---

    def get_resource(
        self,
        uri: str,
        fetch: Optional[FetchFunc] = None,
        etag: Optional[str] = None,
        last_modified: Optional[float] = None,
    ) -> Any:
        """Return cached content for *uri*, optionally refreshing.

        If *fetch* is provided and the cached entry is stale or missing,
        the callable is invoked as ``fetch(uri)`` to obtain fresh
        content.  The result is then cached.

        Args:
            uri: Resource URI.
            fetch: Optional callable ``(uri) -> content``.
            etag: Current ETag from upstream (if known).  When it
                matches the cached ETag the cached content is returned
                without calling *fetch*.
            last_modified: Upstream last-modified timestamp.
        """
        key = self._key(uri)
        cached: Optional[CachedResource] = self._cache.get(key)

        if cached is not None:
            # Conditional: if caller knows the current etag and it matches, reuse.
            if etag is not None and cached.etag == etag:
                return cached.content
            if last_modified is not None and cached.last_modified == last_modified:
                return cached.content
            # If no conditional info, the TTL-based expiry in the cache
            # backend handles staleness — just return what we have.
            if etag is None and last_modified is None:
                return cached.content

        # Cache miss or conditional mismatch — fetch if possible.
        if fetch is None:
            return None

        content = fetch(uri)
        entry = CachedResource(
            uri=uri,
            content=content,
            etag=etag,
            last_modified=last_modified,
        )
        self._cache.set(key, entry, ttl=self._resolve_ttl(uri))
        return content

    def invalidate(self, uri: str) -> bool:
        """Remove cached content for *uri*."""
        return self._cache.delete(self._key(uri))

    def clear(self) -> int:
        """Remove all cached resources."""
        return self._cache.clear(namespace=self._namespace)
