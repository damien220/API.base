"""Context window optimizer — deduplicates and compresses repeated content."""

from __future__ import annotations

import hashlib
from typing import Any, Callable, Optional

from ..base import AbstractCache


class ContextOptimizer:
    """Helps MCP servers reduce redundant content in LLM conversations.

    Tracks content that has already been injected into the context
    window.  When the same content appears again it can be replaced
    with a short summary (or omitted entirely).

    Args:
        cache: Cache backend used to track seen content.
        namespace: Key prefix.
        summarizer: Optional callable ``(content) -> summary``.
            When provided, :meth:`optimize` returns the summary for
            previously-seen content instead of ``None``.
    """

    def __init__(
        self,
        cache: AbstractCache,
        namespace: str = "mcp_ctx",
        summarizer: Optional[Callable[[Any], Any]] = None,
    ) -> None:
        self._cache = cache
        self._namespace = namespace
        self._summarizer = summarizer

    def _content_key(self, content: Any) -> str:
        raw = repr(content).encode()
        digest = hashlib.sha256(raw).hexdigest()
        return f"{self._namespace}:{digest}"

    def is_seen(self, content: Any) -> bool:
        """Check whether *content* has already been recorded."""
        return self._cache.exists(self._content_key(content))

    def record(self, content: Any, ttl: Optional[int] = None) -> None:
        """Mark *content* as seen in this conversation."""
        self._cache.set(self._content_key(content), True, ttl=ttl)

    def optimize(self, content: Any, ttl: Optional[int] = None) -> Any:
        """Return *content* on first encounter, summary/None on repeat.

        First call for a piece of content:
          - Records it in the cache and returns the original content.

        Subsequent calls:
          - If a *summarizer* was provided, returns ``summarizer(content)``.
          - Otherwise returns ``None`` (caller should omit it).
        """
        key = self._content_key(content)
        if self._cache.exists(key):
            if self._summarizer is not None:
                return self._summarizer(content)
            return None
        self._cache.set(key, True, ttl=ttl)
        return content

    def optimize_many(
        self, items: list[Any], ttl: Optional[int] = None
    ) -> list[Any]:
        """Batch version of :meth:`optimize`.

        Returns a list with deduplicated items.  Items that have been
        seen before are replaced with their summary (or filtered out
        if no summarizer is configured).
        """
        results: list[Any] = []
        for item in items:
            optimized = self.optimize(item, ttl=ttl)
            if optimized is not None:
                results.append(optimized)
        return results

    def clear(self) -> int:
        """Reset — forget all previously seen content."""
        return self._cache.clear(namespace=self._namespace)
