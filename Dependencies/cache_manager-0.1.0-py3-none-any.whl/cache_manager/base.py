"""Abstract base class defining the cache interface."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Optional

from .types import CacheStats


class AbstractCache(ABC):
    """Root interface that all cache backends implement.

    Provides the standard get/set/delete/exists/clear contract plus
    batch operations, lifecycle management, and context-manager support.
    """

    # --- Core CRUD ---

    @abstractmethod
    def get(self, key: str, default: Any = None) -> Any:
        """Retrieve a cached value, or *default* if missing / expired."""

    @abstractmethod
    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        """Store *value* under *key* with an optional TTL in seconds."""

    @abstractmethod
    def delete(self, key: str) -> bool:
        """Remove *key*. Returns ``True`` if it existed."""

    @abstractmethod
    def exists(self, key: str) -> bool:
        """Check whether *key* is present and not expired."""

    @abstractmethod
    def clear(self, namespace: Optional[str] = None) -> int:
        """Remove all keys (or those in *namespace*). Returns count removed."""

    # --- Batch operations ---

    def get_many(self, keys: list[str]) -> dict[str, Any]:
        """Batch get. Default implementation loops over :meth:`get`."""
        return {k: v for k in keys if (v := self.get(k)) is not None}

    def set_many(
        self, mapping: dict[str, Any], ttl: Optional[int] = None
    ) -> None:
        """Batch set. Default implementation loops over :meth:`set`."""
        for key, value in mapping.items():
            self.set(key, value, ttl=ttl)

    def delete_many(self, keys: list[str]) -> int:
        """Batch delete. Returns count of keys that existed."""
        return sum(1 for k in keys if self.delete(k))

    # --- Stats ---

    @abstractmethod
    def get_stats(self) -> CacheStats:
        """Return accumulated performance counters."""

    # --- Lifecycle ---

    def connect(self, config: dict[str, Any] | None = None) -> None:
        """Initialize the backend. No-op by default."""

    def disconnect(self) -> None:
        """Shut down the backend. No-op by default."""

    # --- Context manager ---

    def __enter__(self) -> AbstractCache:
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self.disconnect()
