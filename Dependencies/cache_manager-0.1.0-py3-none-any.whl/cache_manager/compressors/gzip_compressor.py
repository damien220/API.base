"""Gzip-based compressor."""

from __future__ import annotations

import gzip

from .base import AbstractCompressor


class GzipCompressor(AbstractCompressor):
    """Compress data using :mod:`gzip`.

    Good for large text payloads (e.g. LLM responses). Trades CPU
    time for smaller stored size.

    Args:
        level: Compression level 0-9 (0 = no compression, 9 = max).
            Defaults to 6 (gzip default).
    """

    def __init__(self, level: int = 6) -> None:
        self._level = level

    def compress(self, data: bytes) -> bytes:
        return gzip.compress(data, compresslevel=self._level)

    def decompress(self, data: bytes) -> bytes:
        return gzip.decompress(data)
