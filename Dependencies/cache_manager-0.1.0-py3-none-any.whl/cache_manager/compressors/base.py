"""Abstract compressor interface and no-op implementation."""

from __future__ import annotations

from abc import ABC, abstractmethod


class AbstractCompressor(ABC):
    """Compresses and decompresses bytes.

    Applied *after* serialization on write and *before* deserialization
    on read.
    """

    @abstractmethod
    def compress(self, data: bytes) -> bytes:
        """Compress *data*."""

    @abstractmethod
    def decompress(self, data: bytes) -> bytes:
        """Decompress *data* back to its original form."""


class NoCompression(AbstractCompressor):
    """Pass-through compressor that does nothing."""

    def compress(self, data: bytes) -> bytes:
        return data

    def decompress(self, data: bytes) -> bytes:
        return data
