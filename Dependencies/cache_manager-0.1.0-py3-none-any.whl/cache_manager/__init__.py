"""cache_manager — abstract, reusable caching package for any Python application."""

from .base import AbstractCache
from .decorators import cached, cache_stampede_protected
from .exceptions import (
    CacheBackendError,
    CacheCapacityError,
    CacheConnectionError,
    CacheException,
    CacheKeyError,
    CacheSerializationError,
)
from .factory import get_cache, is_backend_available, list_available_backends
from .layered import LayeredCache
from .namespace import CacheNamespace
from .types import CacheConfig, CacheEntry, CacheStats

__all__ = [
    "AbstractCache",
    "CacheBackendError",
    "CacheCapacityError",
    "CacheConfig",
    "CacheConnectionError",
    "CacheEntry",
    "CacheException",
    "CacheKeyError",
    "CacheNamespace",
    "CacheSerializationError",
    "CacheStats",
    "LayeredCache",
    "cache_stampede_protected",
    "cached",
    "get_cache",
    "is_backend_available",
    "list_available_backends",
]
