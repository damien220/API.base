"""Factory for instantiating cache backends by name."""

from __future__ import annotations

import importlib
from typing import Any, Type

from .base import AbstractCache
from .exceptions import CacheBackendError

# Registry maps backend name -> (module_path, class_name)
_BACKEND_REGISTRY: dict[str, tuple[str, str]] = {
    "memory": ("cache_manager.backends.memory", "MemoryCache"),
    "file": ("cache_manager.backends.file", "FileCache"),
    "sqlite": ("cache_manager.backends.sqlite", "SQLiteCache"),
    "redis": ("cache_manager.backends.redis", "RedisCache"),
    "mongodb": ("cache_manager.backends.mongodb", "MongoDBCache"),
}

# Cache for loaded classes
_loaded_classes: dict[str, Type[AbstractCache]] = {}


def _load_backend_class(backend: str) -> Type[AbstractCache]:
    """Lazily load and cache a backend implementation class."""
    if backend in _loaded_classes:
        return _loaded_classes[backend]

    if backend not in _BACKEND_REGISTRY:
        available = list(_BACKEND_REGISTRY.keys())
        raise ValueError(
            f"Cache backend '{backend}' is not supported. "
            f"Available backends: {available}"
        )

    module_path, class_name = _BACKEND_REGISTRY[backend]

    try:
        module = importlib.import_module(module_path)
        cls = getattr(module, class_name)
        _loaded_classes[backend] = cls
        return cls
    except ImportError as exc:
        raise CacheBackendError(
            f"Cannot load '{backend}' backend. Required dependency not installed.",
            previous=exc,
        ) from exc


def get_cache(backend: str = "memory", **kwargs: Any) -> AbstractCache:
    """Factory function to create a cache instance.

    Args:
        backend: The type of cache backend (e.g. ``"memory"``).
        **kwargs: Backend-specific configuration passed to the constructor.

    Returns:
        A ready-to-use cache instance.

    Examples:
        >>> cache = get_cache("memory", max_size=1000)
        >>> cache.set("key", "value", ttl=60)
        >>> cache.get("key")
        'value'
    """
    cls = _load_backend_class(backend)
    return cls(**kwargs)


def list_available_backends() -> list[str]:
    """Return all registered backend names.

    Note: some backends may require additional packages (e.g. DB_Package).
    Use :func:`is_backend_available` to check.
    """
    return list(_BACKEND_REGISTRY.keys())


def is_backend_available(backend: str) -> bool:
    """Check whether a backend can be instantiated (dependencies installed)."""
    try:
        _load_backend_class(backend)
        return True
    except (ValueError, CacheBackendError):
        return False
