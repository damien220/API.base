"""Abstract serializer interface."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class AbstractSerializer(ABC):
    """Converts Python objects to bytes and back.

    Used by cache backends that need to persist values to disk, database,
    or network (everything except the in-memory backend which stores
    objects directly).
    """

    @abstractmethod
    def serialize(self, value: Any) -> bytes:
        """Encode *value* into bytes."""

    @abstractmethod
    def deserialize(self, data: bytes) -> Any:
        """Decode *data* back into a Python object."""
