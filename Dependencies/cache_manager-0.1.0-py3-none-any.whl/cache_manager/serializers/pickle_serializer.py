"""Pickle-based serializer (default)."""

from __future__ import annotations

import pickle
from typing import Any

from ..exceptions import CacheSerializationError
from .base import AbstractSerializer


class PickleSerializer(AbstractSerializer):
    """Serialize values using Python's :mod:`pickle` module.

    Handles any picklable Python object.  Uses the highest available
    protocol version for best performance.
    """

    def __init__(self, protocol: int | None = None) -> None:
        self._protocol = protocol if protocol is not None else pickle.HIGHEST_PROTOCOL

    def serialize(self, value: Any) -> bytes:
        try:
            return pickle.dumps(value, protocol=self._protocol)
        except (pickle.PicklingError, TypeError, AttributeError) as exc:
            raise CacheSerializationError(
                f"Cannot pickle value of type {type(value).__name__}",
                previous=exc,
            ) from exc

    def deserialize(self, data: bytes) -> Any:
        try:
            return pickle.loads(data)  # noqa: S301
        except (pickle.UnpicklingError, EOFError, ValueError) as exc:
            raise CacheSerializationError(
                "Cannot unpickle cached data",
                previous=exc,
            ) from exc
