"""JSON-based serializer."""

from __future__ import annotations

import json
from typing import Any

from ..exceptions import CacheSerializationError
from .base import AbstractSerializer


class JSONSerializer(AbstractSerializer):
    """Serialize values using :mod:`json`.

    Only handles JSON-compatible types (str, int, float, bool, None,
    list, dict).  Produces human-readable, cross-language output.
    """

    def serialize(self, value: Any) -> bytes:
        try:
            return json.dumps(value, separators=(",", ":")).encode("utf-8")
        except (TypeError, ValueError, OverflowError) as exc:
            raise CacheSerializationError(
                f"Cannot JSON-serialize value of type {type(value).__name__}",
                previous=exc,
            ) from exc

    def deserialize(self, data: bytes) -> Any:
        try:
            return json.loads(data)
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            raise CacheSerializationError(
                "Cannot JSON-deserialize cached data",
                previous=exc,
            ) from exc
