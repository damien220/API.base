"""General-purpose caching decorators."""

from __future__ import annotations

import functools
import hashlib
import threading
from typing import Any, Callable, Optional

from .base import AbstractCache


def _default_key_builder(func: Callable, args: tuple, kwargs: dict) -> str:
    """Build a deterministic cache key from function name + arguments."""
    parts = [func.__module__, func.__qualname__]
    for a in args:
        parts.append(repr(a))
    for k in sorted(kwargs):
        parts.append(f"{k}={repr(kwargs[k])}")
    raw = ":".join(parts)
    return hashlib.sha256(raw.encode()).hexdigest()


def cached(
    cache: AbstractCache,
    ttl: Optional[int] = None,
    namespace: Optional[str] = None,
    key_builder: Optional[Callable[..., str]] = None,
) -> Callable:
    """Decorator that caches function return values.

    Args:
        cache: The cache backend to use.
        ttl: TTL in seconds for cached entries.
        namespace: Optional prefix prepended to cache keys.
        key_builder: Custom ``(func, args, kwargs) -> str`` key builder.
            Defaults to a SHA-256 hash of the function qualname + arguments.

    Example::

        @cached(cache=my_cache, ttl=600, namespace="api")
        def get_user(user_id: int) -> dict:
            ...
    """
    builder = key_builder or _default_key_builder

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            raw_key = builder(func, args, kwargs)
            key = f"{namespace}:{raw_key}" if namespace else raw_key

            result = cache.get(key)
            if result is not None:
                return result

            result = func(*args, **kwargs)
            cache.set(key, result, ttl=ttl)
            return result

        def invalidate(*args: Any, **kwargs: Any) -> bool:
            """Remove the cached entry for the given arguments."""
            raw_key = builder(func, args, kwargs)
            key = f"{namespace}:{raw_key}" if namespace else raw_key
            return cache.delete(key)

        wrapper.invalidate = invalidate  # type: ignore[attr-defined]
        wrapper.cache = cache  # type: ignore[attr-defined]
        return wrapper

    return decorator


def cache_stampede_protected(
    cache: AbstractCache,
    ttl: Optional[int] = None,
    namespace: Optional[str] = None,
    key_builder: Optional[Callable[..., str]] = None,
    lock_timeout: float = 10.0,
) -> Callable:
    """Decorator that prevents thundering-herd / cache stampede.

    On a cache miss only one caller computes the value; concurrent
    callers for the same key block on a per-key lock and receive the
    computed result once it is ready.

    Args:
        cache: The cache backend to use.
        ttl: TTL in seconds for cached entries.
        namespace: Optional prefix prepended to cache keys.
        key_builder: Custom key builder.
        lock_timeout: Max seconds to wait for the computing thread.
    """
    builder = key_builder or _default_key_builder
    _locks: dict[str, threading.Lock] = {}
    _meta_lock = threading.Lock()

    def _get_lock(key: str) -> threading.Lock:
        with _meta_lock:
            if key not in _locks:
                _locks[key] = threading.Lock()
            return _locks[key]

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            raw_key = builder(func, args, kwargs)
            key = f"{namespace}:{raw_key}" if namespace else raw_key

            result = cache.get(key)
            if result is not None:
                return result

            lock = _get_lock(key)
            acquired = lock.acquire(timeout=lock_timeout)
            try:
                # Double-check after acquiring lock
                result = cache.get(key)
                if result is not None:
                    return result
                result = func(*args, **kwargs)
                cache.set(key, result, ttl=ttl)
                return result
            finally:
                if acquired:
                    lock.release()

        return wrapper

    return decorator
