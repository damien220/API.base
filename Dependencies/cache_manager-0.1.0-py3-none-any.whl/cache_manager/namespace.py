"""Scoped namespace wrapper for any cache backend."""

from __future__ import annotations

from typing import Any, Optional

from .base import AbstractCache
from .types import CacheStats


class CacheNamespace(AbstractCache):
    """Transparent key-prefix wrapper around an existing cache.

    Every operation prefixes keys with ``"<namespace>:"`` so multiple
    logical caches can share a single backend without collision.

    Args:
        cache: The underlying cache backend.
        namespace: Prefix string prepended to every key.
    """

    def __init__(self, cache: AbstractCache, namespace: str) -> None:
        self._cache = cache
        self._namespace = namespace

    def _prefixed(self, key: str) -> str:
        return f"{self._namespace}:{key}"

    # --- Core CRUD ---

    def get(self, key: str, default: Any = None) -> Any:
        return self._cache.get(self._prefixed(key), default)

    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        self._cache.set(self._prefixed(key), value, ttl=ttl)

    def delete(self, key: str) -> bool:
        return self._cache.delete(self._prefixed(key))

    def exists(self, key: str) -> bool:
        return self._cache.exists(self._prefixed(key))

    def clear(self, namespace: Optional[str] = None) -> int:
        effective = (
            f"{self._namespace}:{namespace}" if namespace else self._namespace
        )
        return self._cache.clear(namespace=effective)

    # --- Batch ---

    def get_many(self, keys: list[str]) -> dict[str, Any]:
        prefixed = {self._prefixed(k): k for k in keys}
        results = self._cache.get_many(list(prefixed.keys()))
        return {prefixed[pk]: v for pk, v in results.items()}

    def set_many(self, mapping: dict[str, Any], ttl: Optional[int] = None) -> None:
        self._cache.set_many(
            {self._prefixed(k): v for k, v in mapping.items()}, ttl=ttl,
        )

    def delete_many(self, keys: list[str]) -> int:
        return self._cache.delete_many([self._prefixed(k) for k in keys])

    # --- Stats / lifecycle ---

    def get_stats(self) -> CacheStats:
        return self._cache.get_stats()

    def connect(self, config: dict[str, Any] | None = None) -> None:
        self._cache.connect(config)

    def disconnect(self) -> None:
        self._cache.disconnect()
