"""@llm_cache decorator — caches LLM API call results with token tracking."""

from __future__ import annotations

import functools
import inspect
from typing import Any, Callable, Optional, Sequence

from ..base import AbstractCache
from .entry import LLMCacheEntry
from .key_builder import LLMCacheKeyBuilder
from .token_tracker import TokenTracker


def _extract_token_counts(result: Any) -> tuple[int, int]:
    """Best-effort extraction of input/output token counts from an API response.

    Supports dict responses with an ``usage`` key (OpenAI / Anthropic
    style) and falls back to zero.
    """
    if isinstance(result, dict):
        usage = result.get("usage", {})
        inp = usage.get("input_tokens", usage.get("prompt_tokens", 0))
        out = usage.get("output_tokens", usage.get("completion_tokens", 0))
        return int(inp), int(out)
    # Support objects with a .usage attribute (SDK response objects)
    usage = getattr(result, "usage", None)
    if usage is not None:
        inp = getattr(usage, "input_tokens", getattr(usage, "prompt_tokens", 0))
        out = getattr(usage, "output_tokens", getattr(usage, "completion_tokens", 0))
        return int(inp), int(out)
    return 0, 0


def _extract_model(args: tuple, kwargs: dict, param_names: Sequence[str]) -> str:
    """Pull the ``model`` value from function arguments."""
    if "model" in kwargs:
        return str(kwargs["model"])
    try:
        idx = list(param_names).index("model")
        if idx < len(args):
            return str(args[idx])
    except ValueError:
        pass
    return "unknown"


def llm_cache(
    cache: AbstractCache,
    ttl: Optional[int] = 3600,
    namespace: str = "llm",
    key_builder: Optional[LLMCacheKeyBuilder] = None,
    tracker: Optional[TokenTracker] = None,
    param_names: Sequence[str] = ("messages", "model"),
    deterministic_only: bool = True,
    temperature_threshold: float = 0.0,
) -> Callable:
    """Decorator that caches LLM API call results.

    Args:
        cache: The cache backend to use.
        ttl: TTL in seconds for cached entries.
        namespace: Cache key prefix.
        key_builder: Custom :class:`LLMCacheKeyBuilder`.
        tracker: :class:`TokenTracker` for recording savings.
            Created automatically if ``None``.
        param_names: Positional-argument names in order, used to map
            ``*args`` to named parameters for key building.
        deterministic_only: When ``True``, skip caching if the
            ``temperature`` kwarg exceeds *temperature_threshold*.
        temperature_threshold: Maximum temperature that is considered
            deterministic (default ``0.0``).

    The decorator exposes ``.tracker`` on the wrapped function so callers
    can inspect cumulative savings.

    Example::

        @llm_cache(cache=my_cache, ttl=3600)
        def ask(messages, model="claude-sonnet-4-20250514", **kw):
            return client.messages.create(messages=messages, model=model, **kw)

        ask([{"role": "user", "content": "hi"}])
        print(ask.tracker.tokens_saved)
    """
    builder = key_builder or LLMCacheKeyBuilder(prefix=namespace)
    token_tracker = tracker or TokenTracker()

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            # Bypass caching for non-deterministic calls
            if deterministic_only:
                temp = kwargs.get("temperature")
                if temp is not None and float(temp) > temperature_threshold:
                    return func(*args, **kwargs)

            key = builder.build_key_from_args(args, kwargs, param_names=param_names)

            cached_entry = cache.get(key)
            if cached_entry is not None:
                if isinstance(cached_entry, LLMCacheEntry):
                    token_tracker.record_saving(
                        cached_entry.input_tokens,
                        cached_entry.output_tokens,
                        cached_entry.estimated_cost,
                    )
                    return cached_entry.response
                # Raw cached value (e.g. from a different serializer)
                return cached_entry

            result = func(*args, **kwargs)

            # Build rich entry
            input_tokens, output_tokens = _extract_token_counts(result)
            model = _extract_model(args, kwargs, param_names)
            estimated_cost = token_tracker.estimate_cost(model, input_tokens, output_tokens)

            entry = LLMCacheEntry(
                response=result,
                model=model,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                estimated_cost=estimated_cost,
                cache_key_params=kwargs,
            )
            cache.set(key, entry, ttl=ttl)
            return result

        wrapper.tracker = token_tracker  # type: ignore[attr-defined]
        wrapper.cache = cache  # type: ignore[attr-defined]
        wrapper.key_builder = builder  # type: ignore[attr-defined]
        return wrapper

    return decorator
