"""Deterministic cache-key generation from LLM request parameters."""

from __future__ import annotations

import hashlib
import json
import re
from typing import Any, Optional, Sequence


# Default fields used when building a cache key.
DEFAULT_KEY_FIELDS = ("model", "messages", "temperature", "top_p", "max_tokens", "tools")


class LLMCacheKeyBuilder:
    """Build deterministic cache keys from LLM API call parameters.

    Args:
        fields: Which parameter names to include in the key.
            Defaults to model, messages, temperature, top_p, max_tokens, tools.
        normalize_whitespace: Collapse runs of whitespace in message
            content before hashing so minor formatting differences
            don't produce different keys.
        strip_patterns: Optional list of regex patterns whose matches
            are removed from message content before hashing.  Useful for
            stripping variable parts (timestamps, IDs) so semantically
            equivalent prompts share a key.
        prefix: Static string prepended to every key.
    """

    def __init__(
        self,
        fields: Sequence[str] = DEFAULT_KEY_FIELDS,
        normalize_whitespace: bool = True,
        strip_patterns: Optional[list[str]] = None,
        prefix: str = "llm",
    ) -> None:
        self._fields = tuple(fields)
        self._normalize_ws = normalize_whitespace
        self._strip_res = [re.compile(p) for p in (strip_patterns or [])]
        self._prefix = prefix

    # ------------------------------------------------------------------

    def _normalize_text(self, text: str) -> str:
        for pat in self._strip_res:
            text = pat.sub("", text)
        if self._normalize_ws:
            text = " ".join(text.split())
        return text.strip()

    def _normalize_messages(self, messages: Any) -> Any:
        """Recursively normalise message content strings."""
        if isinstance(messages, str):
            return self._normalize_text(messages)
        if isinstance(messages, dict):
            out: dict[str, Any] = {}
            for k in sorted(messages):
                out[k] = self._normalize_messages(messages[k])
            return out
        if isinstance(messages, (list, tuple)):
            return [self._normalize_messages(m) for m in messages]
        return messages

    def _normalize_value(self, key: str, value: Any) -> Any:
        if key == "messages":
            return self._normalize_messages(value)
        if isinstance(value, dict):
            return {k: value[k] for k in sorted(value)}
        return value

    # ------------------------------------------------------------------

    def build_key(self, **params: Any) -> str:
        """Return a hex-digest key for the given LLM call parameters.

        Only fields listed in ``self._fields`` are included.  Missing
        fields are omitted (not set to ``None``) so that the same
        logical call always maps to the same key regardless of whether
        the caller explicitly passed the default value.
        """
        canonical: dict[str, Any] = {}
        for f in self._fields:
            if f in params:
                canonical[f] = self._normalize_value(f, params[f])
        raw = json.dumps(canonical, sort_keys=True, ensure_ascii=True, default=str)
        digest = hashlib.sha256(raw.encode()).hexdigest()
        return f"{self._prefix}:{digest}" if self._prefix else digest

    def build_key_from_args(
        self,
        func_args: tuple,
        func_kwargs: dict[str, Any],
        param_names: Sequence[str] = ("messages", "model"),
    ) -> str:
        """Build a key by mapping positional args to named parameters.

        This is the entry point used by the ``@llm_cache`` decorator.
        ``param_names`` lists the positional-argument names in order;
        any remaining keyword arguments are merged in.
        """
        merged: dict[str, Any] = {}
        for i, name in enumerate(param_names):
            if i < len(func_args):
                merged[name] = func_args[i]
        merged.update(func_kwargs)
        return self.build_key(**merged)
