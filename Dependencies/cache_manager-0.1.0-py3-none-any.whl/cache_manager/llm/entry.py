"""Data class for cached LLM responses."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any


@dataclass
class LLMCacheEntry:
    """Rich wrapper stored as the cache value for LLM interactions.

    Besides the raw API response it carries token counts and cost
    estimates so the cache can report cumulative savings.
    """

    response: dict[str, Any]
    model: str
    input_tokens: int = 0
    output_tokens: int = 0
    estimated_cost: float = 0.0
    cached_at: float = field(default_factory=time.time)
    cache_key_params: dict[str, Any] = field(default_factory=dict)

    @property
    def total_tokens(self) -> int:
        return self.input_tokens + self.output_tokens

    def to_dict(self) -> dict[str, Any]:
        return {
            "response": self.response,
            "model": self.model,
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "estimated_cost": self.estimated_cost,
            "cached_at": self.cached_at,
            "cache_key_params": self.cache_key_params,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LLMCacheEntry:
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})
