"""Tracks cumulative token and cost savings from LLM cache hits."""

from __future__ import annotations

import threading
from typing import Any, Optional

# Rough per-token cost table (USD) — input / output.
# Users can override via ``TokenTracker(cost_table=...)``.
_DEFAULT_COST_TABLE: dict[str, tuple[float, float]] = {
    # (input $/token, output $/token)
    "claude-opus-4-20250514": (15.0 / 1_000_000, 75.0 / 1_000_000),
    "claude-sonnet-4-20250514": (3.0 / 1_000_000, 15.0 / 1_000_000),
    "claude-haiku-4-20250506": (0.80 / 1_000_000, 4.0 / 1_000_000),
    "gpt-4o": (2.50 / 1_000_000, 10.0 / 1_000_000),
    "gpt-4o-mini": (0.15 / 1_000_000, 0.60 / 1_000_000),
}


class TokenTracker:
    """Accumulates token and dollar savings from cache hits.

    Thread-safe.  The :class:`~cache_manager.llm.decorator.llm_cache`
    decorator calls :meth:`record_saving` on every cache hit.

    Args:
        cost_table: Optional mapping from model name to
            ``(input_cost_per_token, output_cost_per_token)``.
    """

    def __init__(
        self,
        cost_table: Optional[dict[str, tuple[float, float]]] = None,
    ) -> None:
        self._cost_table = cost_table or dict(_DEFAULT_COST_TABLE)
        self._lock = threading.Lock()
        self._tokens_saved = 0
        self._cost_saved = 0.0
        self._hits = 0

    def estimate_cost(
        self,
        model: str,
        input_tokens: int,
        output_tokens: int,
    ) -> float:
        """Return estimated dollar cost for the given token counts."""
        costs = self._cost_table.get(model)
        if costs is None:
            return 0.0
        return input_tokens * costs[0] + output_tokens * costs[1]

    def record_saving(
        self,
        input_tokens: int,
        output_tokens: int,
        estimated_cost: float,
    ) -> None:
        """Record a cache-hit that avoided an LLM call."""
        with self._lock:
            self._tokens_saved += input_tokens + output_tokens
            self._cost_saved += estimated_cost
            self._hits += 1

    @property
    def tokens_saved(self) -> int:
        with self._lock:
            return self._tokens_saved

    @property
    def cost_saved(self) -> float:
        with self._lock:
            return self._cost_saved

    @property
    def cache_hits(self) -> int:
        with self._lock:
            return self._hits

    def reset(self) -> None:
        with self._lock:
            self._tokens_saved = 0
            self._cost_saved = 0.0
            self._hits = 0
