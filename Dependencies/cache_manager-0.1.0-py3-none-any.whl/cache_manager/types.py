"""Shared type definitions and data structures for the cache_manager package."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class CacheEntry:
    """Internal representation of a cached item."""

    key: str
    value: Any
    created_at: float
    expires_at: Optional[float] = None

    def is_expired(self, now: float) -> bool:
        """Check whether this entry has passed its expiry time."""
        if self.expires_at is None:
            return False
        return now >= self.expires_at


@dataclass
class CacheStats:
    """Accumulated cache performance counters.

    Returned by ``AbstractCache.get_stats()`` so callers can inspect
    hit rates, eviction pressure, and (for LLM caches) token savings.
    """

    hits: int = 0
    misses: int = 0
    sets: int = 0
    deletes: int = 0
    evictions: int = 0
    total_items: int = 0
    memory_bytes: Optional[int] = None
    token_savings: int = 0
    cost_savings: float = 0.0

    @property
    def hit_rate(self) -> float:
        """Fraction of get() calls that returned a cached value."""
        total = self.hits + self.misses
        if total == 0:
            return 0.0
        return self.hits / total


@dataclass
class CacheConfig:
    """Configuration for instantiating a cache backend.

    Backends only read the fields they care about; the rest are ignored.
    """

    backend: str = "memory"
    namespace: str = ""
    default_ttl: Optional[int] = 3600
    max_size: Optional[int] = 10000
    eviction_policy: str = "lru"
    serializer: str = "pickle"
    compressor: str = "none"
    key_max_length: int = 250

    # File backend
    file_cache_dir: str = "./cache"

    # SQLite backend (via DB_Package)
    sqlite_db_path: str = "./cache.db"

    # Redis backend (via DB_Package)
    redis_host: str = "localhost"
    redis_port: int = 6379
    redis_db: int = 0
    redis_password: Optional[str] = None

    # MongoDB backend (via DB_Package)
    mongodb_connection_string: str = "mongodb://localhost:27017"
    mongodb_database: str = "cache"
    mongodb_collection: str = "cache_entries"

    # Layered cache
    layers: Optional[list[dict[str, Any]]] = None

    # LLM caching
    llm_cache_enabled: bool = False
    llm_default_ttl: int = 3600
    llm_deterministic_only: bool = True
    llm_track_tokens: bool = True
    llm_track_cost: bool = True

    # MCP caching
    mcp_tool_cache_enabled: bool = False
    mcp_tool_ttl_map: Optional[dict[str, int]] = None
    mcp_resource_cache_enabled: bool = False

    # Logging (via Logger_Package)
    log_enabled: bool = True
    log_level: str = "DEBUG"
    log_stats_interval: int = 300

    # Stampede protection
    stampede_protection: bool = False
    stampede_lock_timeout: int = 10
