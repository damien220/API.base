"""Thread-safe cache statistics tracker."""

from __future__ import annotations

import threading

from .types import CacheStats


class StatsTracker:
    """Mutable, thread-safe wrapper around :class:`CacheStats`.

    Each cache backend holds one ``StatsTracker`` and calls the
    ``record_*`` helpers on every operation.  ``snapshot()`` returns
    an immutable copy safe to pass to callers.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._hits = 0
        self._misses = 0
        self._sets = 0
        self._deletes = 0
        self._evictions = 0

    def record_hit(self) -> None:
        with self._lock:
            self._hits += 1

    def record_miss(self) -> None:
        with self._lock:
            self._misses += 1

    def record_set(self) -> None:
        with self._lock:
            self._sets += 1

    def record_delete(self) -> None:
        with self._lock:
            self._deletes += 1

    def record_eviction(self) -> None:
        with self._lock:
            self._evictions += 1

    def snapshot(self, total_items: int = 0, memory_bytes: int | None = None) -> CacheStats:
        """Return a frozen copy of current counters."""
        with self._lock:
            return CacheStats(
                hits=self._hits,
                misses=self._misses,
                sets=self._sets,
                deletes=self._deletes,
                evictions=self._evictions,
                total_items=total_items,
                memory_bytes=memory_bytes,
            )

    def reset(self) -> None:
        """Zero all counters."""
        with self._lock:
            self._hits = 0
            self._misses = 0
            self._sets = 0
            self._deletes = 0
            self._evictions = 0
