"""First-In-First-Out eviction policy."""

from __future__ import annotations

from collections import deque
from typing import Optional

from .base import AbstractEvictionPolicy


class FIFOPolicy(AbstractEvictionPolicy):
    """Evicts the key that was inserted earliest.

    Access (reads) do **not** change the eviction order — only
    insertion order matters.
    """

    def __init__(self) -> None:
        self._queue: deque[str] = deque()
        self._keys: set[str] = set()

    def on_access(self, key: str) -> None:
        pass  # FIFO ignores access patterns

    def on_set(self, key: str) -> None:
        if key not in self._keys:
            self._queue.append(key)
            self._keys.add(key)

    def on_delete(self, key: str) -> None:
        self._keys.discard(key)
        # Lazy removal: the key stays in the deque and is skipped during evict()

    def evict(self) -> Optional[str]:
        while self._queue:
            key = self._queue.popleft()
            if key in self._keys:
                self._keys.discard(key)
                return key
        return None

    def clear(self) -> None:
        self._queue.clear()
        self._keys.clear()
