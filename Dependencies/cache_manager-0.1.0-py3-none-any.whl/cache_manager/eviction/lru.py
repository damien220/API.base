"""Least-Recently-Used eviction policy."""

from __future__ import annotations

from collections import OrderedDict
from typing import Optional

from .base import AbstractEvictionPolicy


class LRUPolicy(AbstractEvictionPolicy):
    """Evicts the key that was accessed least recently.

    Internally uses an :class:`OrderedDict` where the *most-recently
    used* key is always at the end.
    """

    def __init__(self) -> None:
        self._order: OrderedDict[str, None] = OrderedDict()

    def on_access(self, key: str) -> None:
        if key in self._order:
            self._order.move_to_end(key)

    def on_set(self, key: str) -> None:
        if key in self._order:
            self._order.move_to_end(key)
        else:
            self._order[key] = None

    def on_delete(self, key: str) -> None:
        self._order.pop(key, None)

    def evict(self) -> Optional[str]:
        if not self._order:
            return None
        key, _ = self._order.popitem(last=False)
        return key

    def clear(self) -> None:
        self._order.clear()
