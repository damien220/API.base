"""Abstract eviction policy interface."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional


class AbstractEvictionPolicy(ABC):
    """Interface that every eviction policy must implement.

    The cache backend calls ``on_access`` / ``on_set`` / ``on_delete``
    to keep the policy's internal bookkeeping up to date, then calls
    ``evict`` when it needs to free a slot.
    """

    @abstractmethod
    def on_access(self, key: str) -> None:
        """Record that *key* was read (get / exists)."""

    @abstractmethod
    def on_set(self, key: str) -> None:
        """Record that *key* was written (set)."""

    @abstractmethod
    def on_delete(self, key: str) -> None:
        """Record that *key* was explicitly removed."""

    @abstractmethod
    def evict(self) -> Optional[str]:
        """Return the key that should be evicted, or ``None`` if empty."""

    @abstractmethod
    def clear(self) -> None:
        """Reset all internal state."""
