"""Least-Frequently-Used eviction policy."""

from __future__ import annotations

from typing import Optional

from .base import AbstractEvictionPolicy


class LFUPolicy(AbstractEvictionPolicy):
    """Evicts the key that has been accessed the fewest times.

    Ties are broken by insertion order (oldest inserted is evicted first).
    """

    def __init__(self) -> None:
        self._freq: dict[str, int] = {}
        self._order: list[str] = []

    def on_access(self, key: str) -> None:
        if key in self._freq:
            self._freq[key] += 1

    def on_set(self, key: str) -> None:
        if key not in self._freq:
            self._freq[key] = 1
            self._order.append(key)
        else:
            self._freq[key] += 1

    def on_delete(self, key: str) -> None:
        self._freq.pop(key, None)
        try:
            self._order.remove(key)
        except ValueError:
            pass

    def evict(self) -> Optional[str]:
        if not self._freq:
            return None
        min_freq = min(self._freq.values())
        for key in self._order:
            if self._freq.get(key) == min_freq:
                self.on_delete(key)
                return key
        return None  # pragma: no cover

    def clear(self) -> None:
        self._freq.clear()
        self._order.clear()
