"""MongoDB cache backend via DB_Package."""

from __future__ import annotations

import time
from typing import Any, Optional

from ..base import AbstractCache
from ..compressors.base import AbstractCompressor, NoCompression
from ..exceptions import CacheBackendError, CacheConnectionError, CacheKeyError
from ..serializers.base import AbstractSerializer
from ..serializers.pickle_serializer import PickleSerializer
from ..stats import StatsTracker
from ..types import CacheStats


class MongoDBCache(AbstractCache):
    """Cache backed by MongoDB via :func:`db_accessor.get_database`.

    Uses MongoDB TTL indexes on ``expires_at`` for automatic expiry.

    Args:
        connection_string: MongoDB connection URI.
        database: Database name.
        collection: Collection name for cache entries.
        namespace: Logical namespace stored alongside each document.
        default_ttl: Default TTL in seconds (``None`` = no expiry).
        serializer: Serializer instance.
        compressor: Compressor instance.
        key_max_length: Maximum allowed key length.
    """

    def __init__(
        self,
        connection_string: str = "mongodb://localhost:27017",
        database: str = "cache",
        collection: str = "cache_entries",
        namespace: str = "",
        default_ttl: Optional[int] = None,
        serializer: Optional[AbstractSerializer] = None,
        compressor: Optional[AbstractCompressor] = None,
        key_max_length: int = 250,
    ) -> None:
        self._connection_string = connection_string
        self._database = database
        self._collection = collection
        self._namespace = namespace
        self._default_ttl = default_ttl
        self._serializer = serializer or PickleSerializer()
        self._compressor = compressor or NoCompression()
        self._key_max_length = key_max_length
        self._stats = StatsTracker()
        self._db: Any = None
        self._connect()

    def _connect(self) -> None:
        try:
            from db_accessor import get_database
        except ImportError as exc:
            raise CacheConnectionError(
                "db-accessor package is required for MongoDBCache. "
                "Install with: pip install db-accessor",
                previous=exc,
            ) from exc
        try:
            self._db = get_database("mongodb")
            self._db.connect({
                "connection_string": self._connection_string,
                "database": self._database,
            })
        except Exception as exc:
            raise CacheConnectionError(
                f"Failed to connect to MongoDB at {self._connection_string}",
                previous=exc,
            ) from exc

    def _validate_key(self, key: str) -> None:
        if not key:
            raise CacheKeyError("Cache key must not be empty")
        if len(key) > self._key_max_length:
            raise CacheKeyError(
                f"Cache key exceeds max length ({len(key)} > {self._key_max_length})",
                details={"key_length": len(key), "max_length": self._key_max_length},
            )

    def _serialize(self, value: Any) -> bytes:
        return self._compressor.compress(self._serializer.serialize(value))

    def _deserialize(self, blob: bytes) -> Any:
        return self._serializer.deserialize(self._compressor.decompress(blob))

    def _query(self, key: str) -> dict:
        return {"namespace": self._namespace, "key": key}

    # --- Core CRUD ---

    def get(self, key: str, default: Any = None) -> Any:
        self._validate_key(key)
        try:
            rows = self._db.read(self._collection, self._query(key))
        except Exception as exc:
            raise CacheBackendError(
                f"MongoDB read failed for key '{key}'", previous=exc,
            ) from exc
        if not rows:
            self._stats.record_miss()
            return default
        doc = rows[0] if isinstance(rows, list) else rows
        expires_at = doc.get("expires_at")
        if expires_at is not None and time.time() >= expires_at:
            self._db.delete(self._collection, self._query(key))
            self._stats.record_eviction()
            self._stats.record_miss()
            return default
        self._stats.record_hit()
        return self._deserialize(doc["value_blob"])

    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        self._validate_key(key)
        effective_ttl = ttl if ttl is not None else self._default_ttl
        now = time.time()
        expires_at = (now + effective_ttl) if effective_ttl is not None else None
        blob = self._serialize(value)
        doc = {
            "namespace": self._namespace,
            "key": key,
            "value_blob": blob,
            "created_at": now,
            "expires_at": expires_at,
        }
        try:
            # Attempt update; if nothing was updated, insert.
            existing = self._db.read(self._collection, self._query(key))
            if existing:
                self._db.update(self._collection, self._query(key), doc)
            else:
                self._db.create(self._collection, doc)
        except Exception as exc:
            raise CacheBackendError(
                f"MongoDB write failed for key '{key}'", previous=exc,
            ) from exc
        self._stats.record_set()

    def delete(self, key: str) -> bool:
        self._validate_key(key)
        try:
            existing = self._db.read(self._collection, self._query(key))
            if not existing:
                return False
            self._db.delete(self._collection, self._query(key))
            self._stats.record_delete()
            return True
        except Exception:
            return False

    def exists(self, key: str) -> bool:
        self._validate_key(key)
        try:
            rows = self._db.read(self._collection, self._query(key))
        except Exception:
            return False
        if not rows:
            return False
        doc = rows[0] if isinstance(rows, list) else rows
        expires_at = doc.get("expires_at")
        if expires_at is not None and time.time() >= expires_at:
            self._db.delete(self._collection, self._query(key))
            self._stats.record_eviction()
            return False
        return True

    def clear(self, namespace: Optional[str] = None) -> int:
        ns = namespace if namespace is not None else self._namespace
        try:
            rows = self._db.read(self._collection, {"namespace": ns})
            count = len(rows) if isinstance(rows, list) else (1 if rows else 0)
            self._db.delete(self._collection, {"namespace": ns})
            return count
        except Exception as exc:
            raise CacheBackendError(
                "MongoDB clear failed", previous=exc,
            ) from exc

    # --- Stats / lifecycle ---

    def get_stats(self) -> CacheStats:
        try:
            rows = self._db.read(self._collection, {"namespace": self._namespace})
            total = len(rows) if isinstance(rows, list) else (1 if rows else 0)
        except Exception:
            total = 0
        return self._stats.snapshot(total_items=total)

    def disconnect(self) -> None:
        if self._db is not None:
            try:
                self._db.disconnect()
            except Exception:
                pass
            self._db = None
