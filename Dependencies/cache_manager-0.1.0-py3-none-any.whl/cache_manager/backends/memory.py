"""In-memory cache backend with TTL and pluggable eviction."""

from __future__ import annotations

import sys
import threading
import time
from typing import Any, Optional

from ..base import AbstractCache
from ..eviction.base import AbstractEvictionPolicy
from ..eviction.lru import LRUPolicy
from ..exceptions import CacheKeyError
from ..stats import StatsTracker
from ..types import CacheEntry, CacheStats


class MemoryCache(AbstractCache):
    """Dict-backed cache with TTL tracking, configurable max size,
    and pluggable eviction policy.

    Thread-safe via :class:`threading.Lock`.

    Args:
        max_size: Maximum number of entries. ``None`` means unlimited.
        default_ttl: Default TTL in seconds applied when ``set()`` is
            called without an explicit *ttl*. ``None`` means no expiry.
        eviction_policy: An :class:`AbstractEvictionPolicy` instance.
            Defaults to :class:`LRUPolicy`.
        key_max_length: Maximum allowed key length in characters.
    """

    def __init__(
        self,
        max_size: Optional[int] = None,
        default_ttl: Optional[int] = None,
        eviction_policy: Optional[AbstractEvictionPolicy] = None,
        key_max_length: int = 250,
    ) -> None:
        self._store: dict[str, CacheEntry] = {}
        self._lock = threading.Lock()
        self._max_size = max_size
        self._default_ttl = default_ttl
        self._eviction = eviction_policy or LRUPolicy()
        self._key_max_length = key_max_length
        self._stats = StatsTracker()

    # --- Helpers ---

    def _validate_key(self, key: str) -> None:
        if not key:
            raise CacheKeyError("Cache key must not be empty")
        if len(key) > self._key_max_length:
            raise CacheKeyError(
                f"Cache key exceeds max length ({len(key)} > {self._key_max_length})",
                details={"key_length": len(key), "max_length": self._key_max_length},
            )

    def _is_expired(self, entry: CacheEntry) -> bool:
        return entry.is_expired(time.time())

    def _evict_expired(self) -> None:
        """Remove all expired entries (called while holding the lock)."""
        now = time.time()
        expired_keys = [k for k, e in self._store.items() if e.is_expired(now)]
        for key in expired_keys:
            del self._store[key]
            self._eviction.on_delete(key)
            self._stats.record_eviction()

    def _evict_one(self) -> None:
        """Evict a single entry according to the eviction policy."""
        key = self._eviction.evict()
        if key is not None and key in self._store:
            del self._store[key]
            self._stats.record_eviction()

    # --- Core CRUD ---

    def get(self, key: str, default: Any = None) -> Any:
        self._validate_key(key)
        with self._lock:
            entry = self._store.get(key)
            if entry is None or self._is_expired(entry):
                if entry is not None:
                    del self._store[key]
                    self._eviction.on_delete(key)
                    self._stats.record_eviction()
                self._stats.record_miss()
                return default
            self._eviction.on_access(key)
            self._stats.record_hit()
            return entry.value

    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        self._validate_key(key)
        effective_ttl = ttl if ttl is not None else self._default_ttl
        now = time.time()
        expires_at = (now + effective_ttl) if effective_ttl is not None else None
        entry = CacheEntry(key=key, value=value, created_at=now, expires_at=expires_at)

        with self._lock:
            is_new = key not in self._store

            if is_new and self._max_size is not None and len(self._store) >= self._max_size:
                self._evict_expired()
                while self._max_size is not None and len(self._store) >= self._max_size:
                    self._evict_one()

            self._store[key] = entry
            self._eviction.on_set(key)
            self._stats.record_set()

    def delete(self, key: str) -> bool:
        self._validate_key(key)
        with self._lock:
            if key in self._store:
                del self._store[key]
                self._eviction.on_delete(key)
                self._stats.record_delete()
                return True
            return False

    def exists(self, key: str) -> bool:
        self._validate_key(key)
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                return False
            if self._is_expired(entry):
                del self._store[key]
                self._eviction.on_delete(key)
                self._stats.record_eviction()
                return False
            return True

    def clear(self, namespace: Optional[str] = None) -> int:
        with self._lock:
            if namespace is None:
                count = len(self._store)
                self._store.clear()
                self._eviction.clear()
                return count
            keys = [k for k in self._store if k.startswith(f"{namespace}:")]
            for key in keys:
                del self._store[key]
                self._eviction.on_delete(key)
            return len(keys)

    # --- Stats ---

    def get_stats(self) -> CacheStats:
        with self._lock:
            total = len(self._store)
            mem = sum(sys.getsizeof(e.value) for e in self._store.values())
        return self._stats.snapshot(total_items=total, memory_bytes=mem)
