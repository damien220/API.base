"""SQLite cache backend via DB_Package."""

from __future__ import annotations

import time
from typing import Any, Optional

from ..base import AbstractCache
from ..compressors.base import AbstractCompressor, NoCompression
from ..exceptions import CacheBackendError, CacheConnectionError, CacheKeyError
from ..serializers.base import AbstractSerializer
from ..serializers.pickle_serializer import PickleSerializer
from ..stats import StatsTracker
from ..types import CacheStats

_TABLE = "cache_entries"
_CREATE_SQL = f"""
CREATE TABLE IF NOT EXISTS {_TABLE} (
    namespace TEXT NOT NULL DEFAULT '',
    key       TEXT NOT NULL,
    value_blob BLOB NOT NULL,
    created_at REAL NOT NULL,
    expires_at REAL,
    PRIMARY KEY (namespace, key)
)
"""
_CREATE_INDEX_SQL = f"""
CREATE INDEX IF NOT EXISTS idx_cache_expires ON {_TABLE} (expires_at)
"""


class SQLiteCache(AbstractCache):
    """Cache backed by a SQLite database via :func:`db_accessor.get_database`.

    Args:
        db_path: Path to the SQLite database file.
        default_ttl: Default TTL in seconds (``None`` = no expiry).
        namespace: Namespace string to partition keys.
        serializer: Serializer instance.
        compressor: Compressor instance.
        key_max_length: Maximum allowed key length.
    """

    def __init__(
        self,
        db_path: str = "./cache.db",
        default_ttl: Optional[int] = None,
        namespace: str = "",
        serializer: Optional[AbstractSerializer] = None,
        compressor: Optional[AbstractCompressor] = None,
        key_max_length: int = 250,
    ) -> None:
        self._db_path = db_path
        self._default_ttl = default_ttl
        self._namespace = namespace
        self._serializer = serializer or PickleSerializer()
        self._compressor = compressor or NoCompression()
        self._key_max_length = key_max_length
        self._stats = StatsTracker()
        self._db: Any = None
        self._connect()

    def _connect(self) -> None:
        try:
            from db_accessor import get_database
        except ImportError as exc:
            raise CacheConnectionError(
                "db-accessor package is required for SQLiteCache. "
                "Install with: pip install db-accessor",
                previous=exc,
            ) from exc
        try:
            self._db = get_database("sqlite")
            self._db.connect({"database": self._db_path})
            self._db.execute_custom_query({"query": _CREATE_SQL, "params": ()})
            self._db.execute_custom_query({"query": _CREATE_INDEX_SQL, "params": ()})
        except Exception as exc:
            raise CacheConnectionError(
                f"Failed to connect to SQLite at {self._db_path}",
                previous=exc,
            ) from exc

    def _validate_key(self, key: str) -> None:
        if not key:
            raise CacheKeyError("Cache key must not be empty")
        if len(key) > self._key_max_length:
            raise CacheKeyError(
                f"Cache key exceeds max length ({len(key)} > {self._key_max_length})",
                details={"key_length": len(key), "max_length": self._key_max_length},
            )

    def _serialize(self, value: Any) -> bytes:
        return self._compressor.compress(self._serializer.serialize(value))

    def _deserialize(self, blob: bytes) -> Any:
        return self._serializer.deserialize(self._compressor.decompress(blob))

    def _purge_expired(self) -> None:
        """Delete expired rows."""
        try:
            self._db.execute_custom_query({
                "query": f"DELETE FROM {_TABLE} WHERE expires_at IS NOT NULL AND expires_at <= ?",
                "params": (time.time(),),
            })
        except Exception:
            pass

    # --- Core CRUD ---

    def get(self, key: str, default: Any = None) -> Any:
        self._validate_key(key)
        try:
            rows = self._db.execute_custom_query({
                "query": f"SELECT value_blob, expires_at FROM {_TABLE} WHERE namespace = ? AND key = ?",
                "params": (self._namespace, key),
            })
        except Exception as exc:
            raise CacheBackendError(
                f"SQLite read failed for key '{key}'", previous=exc,
            ) from exc

        if not rows:
            self._stats.record_miss()
            return default

        row = rows[0]
        expires_at = row[1]
        if expires_at is not None and time.time() >= expires_at:
            self._delete_row(key)
            self._stats.record_eviction()
            self._stats.record_miss()
            return default

        self._stats.record_hit()
        return self._deserialize(row[0])

    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        self._validate_key(key)
        effective_ttl = ttl if ttl is not None else self._default_ttl
        now = time.time()
        expires_at = (now + effective_ttl) if effective_ttl is not None else None
        blob = self._serialize(value)
        try:
            self._db.execute_custom_query({
                "query": (
                    f"INSERT OR REPLACE INTO {_TABLE} "
                    "(namespace, key, value_blob, created_at, expires_at) "
                    "VALUES (?, ?, ?, ?, ?)"
                ),
                "params": (self._namespace, key, blob, now, expires_at),
            })
        except Exception as exc:
            raise CacheBackendError(
                f"SQLite write failed for key '{key}'", previous=exc,
            ) from exc
        self._stats.record_set()

    def _delete_row(self, key: str) -> bool:
        try:
            self._db.execute_custom_query({
                "query": f"DELETE FROM {_TABLE} WHERE namespace = ? AND key = ?",
                "params": (self._namespace, key),
            })
            return True
        except Exception:
            return False

    def delete(self, key: str) -> bool:
        self._validate_key(key)
        try:
            rows = self._db.execute_custom_query({
                "query": f"SELECT 1 FROM {_TABLE} WHERE namespace = ? AND key = ?",
                "params": (self._namespace, key),
            })
        except Exception:
            return False
        if not rows:
            return False
        self._delete_row(key)
        self._stats.record_delete()
        return True

    def exists(self, key: str) -> bool:
        self._validate_key(key)
        try:
            rows = self._db.execute_custom_query({
                "query": f"SELECT expires_at FROM {_TABLE} WHERE namespace = ? AND key = ?",
                "params": (self._namespace, key),
            })
        except Exception:
            return False
        if not rows:
            return False
        expires_at = rows[0][0]
        if expires_at is not None and time.time() >= expires_at:
            self._delete_row(key)
            self._stats.record_eviction()
            return False
        return True

    def clear(self, namespace: Optional[str] = None) -> int:
        ns = namespace if namespace is not None else self._namespace
        try:
            count_rows = self._db.execute_custom_query({
                "query": f"SELECT COUNT(*) FROM {_TABLE} WHERE namespace = ?",
                "params": (ns,),
            })
            count = count_rows[0][0] if count_rows else 0
            self._db.execute_custom_query({
                "query": f"DELETE FROM {_TABLE} WHERE namespace = ?",
                "params": (ns,),
            })
            return count
        except Exception as exc:
            raise CacheBackendError(
                "SQLite clear failed", previous=exc,
            ) from exc

    # --- Stats / lifecycle ---

    def get_stats(self) -> CacheStats:
        try:
            rows = self._db.execute_custom_query({
                "query": f"SELECT COUNT(*) FROM {_TABLE} WHERE namespace = ?",
                "params": (self._namespace,),
            })
            total = rows[0][0] if rows else 0
        except Exception:
            total = 0
        return self._stats.snapshot(total_items=total)

    def disconnect(self) -> None:
        if self._db is not None:
            try:
                self._db.disconnect()
            except Exception:
                pass
            self._db = None
