"""Redis cache backend via DB_Package."""

from __future__ import annotations

import time
from typing import Any, Optional

from ..base import AbstractCache
from ..compressors.base import AbstractCompressor, NoCompression
from ..exceptions import CacheBackendError, CacheConnectionError, CacheKeyError
from ..serializers.base import AbstractSerializer
from ..serializers.pickle_serializer import PickleSerializer
from ..stats import StatsTracker
from ..types import CacheStats


class RedisCache(AbstractCache):
    """Cache backed by Redis via :func:`db_accessor.get_database`.

    Uses Redis native TTL (``SETEX``) for expiry.

    Args:
        host: Redis host.
        port: Redis port.
        db: Redis database number.
        password: Optional Redis password.
        namespace: Key prefix for partitioning.
        default_ttl: Default TTL in seconds (``None`` = no expiry).
        serializer: Serializer instance.
        compressor: Compressor instance.
        key_max_length: Maximum allowed key length.
    """

    def __init__(
        self,
        host: str = "localhost",
        port: int = 6379,
        db: int = 0,
        password: Optional[str] = None,
        namespace: str = "",
        default_ttl: Optional[int] = None,
        serializer: Optional[AbstractSerializer] = None,
        compressor: Optional[AbstractCompressor] = None,
        key_max_length: int = 250,
    ) -> None:
        self._host = host
        self._port = port
        self._db_num = db
        self._password = password
        self._namespace = namespace
        self._default_ttl = default_ttl
        self._serializer = serializer or PickleSerializer()
        self._compressor = compressor or NoCompression()
        self._key_max_length = key_max_length
        self._stats = StatsTracker()
        self._db: Any = None
        self._connect()

    def _connect(self) -> None:
        try:
            from db_accessor import get_database
        except ImportError as exc:
            raise CacheConnectionError(
                "db-accessor package is required for RedisCache. "
                "Install with: pip install db-accessor",
                previous=exc,
            ) from exc
        try:
            self._db = get_database("redis")
            conn_details: dict[str, Any] = {
                "host": self._host,
                "port": self._port,
                "db": self._db_num,
            }
            if self._password:
                conn_details["password"] = self._password
            self._db.connect(conn_details)
        except Exception as exc:
            raise CacheConnectionError(
                f"Failed to connect to Redis at {self._host}:{self._port}",
                previous=exc,
            ) from exc

    def _validate_key(self, key: str) -> None:
        if not key:
            raise CacheKeyError("Cache key must not be empty")
        if len(key) > self._key_max_length:
            raise CacheKeyError(
                f"Cache key exceeds max length ({len(key)} > {self._key_max_length})",
                details={"key_length": len(key), "max_length": self._key_max_length},
            )

    def _full_key(self, key: str) -> str:
        return f"{self._namespace}:{key}" if self._namespace else key

    def _serialize(self, value: Any) -> bytes:
        return self._compressor.compress(self._serializer.serialize(value))

    def _deserialize(self, blob: bytes) -> Any:
        return self._serializer.deserialize(self._compressor.decompress(blob))

    # --- Core CRUD ---

    def get(self, key: str, default: Any = None) -> Any:
        self._validate_key(key)
        try:
            result = self._db.execute_custom_query({
                "command": "GET",
                "args": [self._full_key(key)],
            })
        except Exception as exc:
            raise CacheBackendError(
                f"Redis GET failed for key '{key}'", previous=exc,
            ) from exc
        if result is None:
            self._stats.record_miss()
            return default
        self._stats.record_hit()
        return self._deserialize(result if isinstance(result, bytes) else result.encode())

    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        self._validate_key(key)
        effective_ttl = ttl if ttl is not None else self._default_ttl
        blob = self._serialize(value)
        try:
            if effective_ttl is not None:
                self._db.execute_custom_query({
                    "command": "SETEX",
                    "args": [self._full_key(key), effective_ttl, blob],
                })
            else:
                self._db.execute_custom_query({
                    "command": "SET",
                    "args": [self._full_key(key), blob],
                })
        except Exception as exc:
            raise CacheBackendError(
                f"Redis SET failed for key '{key}'", previous=exc,
            ) from exc
        self._stats.record_set()

    def delete(self, key: str) -> bool:
        self._validate_key(key)
        try:
            count = self._db.execute_custom_query({
                "command": "DEL",
                "args": [self._full_key(key)],
            })
        except Exception as exc:
            raise CacheBackendError(
                f"Redis DEL failed for key '{key}'", previous=exc,
            ) from exc
        existed = count is not None and int(count) > 0
        if existed:
            self._stats.record_delete()
        return existed

    def exists(self, key: str) -> bool:
        self._validate_key(key)
        try:
            result = self._db.execute_custom_query({
                "command": "EXISTS",
                "args": [self._full_key(key)],
            })
            return result is not None and int(result) > 0
        except Exception:
            return False

    def clear(self, namespace: Optional[str] = None) -> int:
        prefix = namespace if namespace is not None else self._namespace
        pattern = f"{prefix}:*" if prefix else "*"
        try:
            keys = self._db.execute_custom_query({
                "command": "KEYS",
                "args": [pattern],
            })
            if not keys:
                return 0
            count = self._db.execute_custom_query({
                "command": "DEL",
                "args": list(keys),
            })
            return int(count) if count else 0
        except Exception as exc:
            raise CacheBackendError(
                "Redis clear failed", previous=exc,
            ) from exc

    # --- Stats / lifecycle ---

    def get_stats(self) -> CacheStats:
        return self._stats.snapshot(total_items=0)

    def disconnect(self) -> None:
        if self._db is not None:
            try:
                self._db.disconnect()
            except Exception:
                pass
            self._db = None
