"""File-system cache backend — one file per key, zero external dependencies."""

from __future__ import annotations

import hashlib
import struct
import time
from pathlib import Path
from typing import Any, Optional

from ..base import AbstractCache
from ..compressors.base import AbstractCompressor, NoCompression
from ..exceptions import CacheBackendError, CacheKeyError
from ..serializers.base import AbstractSerializer
from ..serializers.pickle_serializer import PickleSerializer
from ..stats import StatsTracker
from ..types import CacheStats


# First 8 bytes of each file store expires_at as big-endian double.
# 0.0 means "never expires".
_EXPIRES_BYTES = 8
_NO_EXPIRY = 0.0


class FileCache(AbstractCache):
    """Persist cache entries as individual files in a directory.

    Each key is mapped to a filename via SHA-256 so any key string is
    safe on any filesystem.  Serialization and compression are pluggable.

    Args:
        cache_dir: Directory to store cache files (created if missing).
        default_ttl: Default TTL in seconds (``None`` = no expiry).
        serializer: Serializer instance (defaults to :class:`PickleSerializer`).
        compressor: Compressor instance (defaults to :class:`NoCompression`).
        key_max_length: Maximum allowed key length in characters.
    """

    def __init__(
        self,
        cache_dir: str = "./cache",
        default_ttl: Optional[int] = None,
        serializer: Optional[AbstractSerializer] = None,
        compressor: Optional[AbstractCompressor] = None,
        key_max_length: int = 250,
    ) -> None:
        self._cache_dir = Path(cache_dir)
        self._cache_dir.mkdir(parents=True, exist_ok=True)
        self._default_ttl = default_ttl
        self._serializer = serializer or PickleSerializer()
        self._compressor = compressor or NoCompression()
        self._key_max_length = key_max_length
        self._stats = StatsTracker()

    # --- Helpers ---

    def _validate_key(self, key: str) -> None:
        if not key:
            raise CacheKeyError("Cache key must not be empty")
        if len(key) > self._key_max_length:
            raise CacheKeyError(
                f"Cache key exceeds max length ({len(key)} > {self._key_max_length})",
                details={"key_length": len(key), "max_length": self._key_max_length},
            )

    def _key_to_path(self, key: str) -> Path:
        digest = hashlib.sha256(key.encode()).hexdigest()
        return self._cache_dir / digest[:2] / digest[2:]

    def _write_entry(self, path: Path, value: Any, expires_at: float) -> None:
        payload = self._compressor.compress(self._serializer.serialize(value))
        header = struct.pack(">d", expires_at)
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".tmp")
        try:
            tmp.write_bytes(header + payload)
            tmp.replace(path)
        except OSError as exc:
            tmp.unlink(missing_ok=True)
            raise CacheBackendError(
                f"Failed to write cache file: {exc}",
                previous=exc,
            ) from exc

    def _read_entry(self, path: Path) -> Optional[tuple[float, Any]]:
        """Return ``(expires_at, value)`` or ``None``."""
        try:
            raw = path.read_bytes()
        except FileNotFoundError:
            return None
        except OSError as exc:
            raise CacheBackendError(
                f"Failed to read cache file: {exc}",
                previous=exc,
            ) from exc
        if len(raw) < _EXPIRES_BYTES:
            path.unlink(missing_ok=True)
            return None
        expires_at = struct.unpack(">d", raw[:_EXPIRES_BYTES])[0]
        payload = raw[_EXPIRES_BYTES:]
        value = self._serializer.deserialize(self._compressor.decompress(payload))
        return expires_at, value

    def _is_expired(self, expires_at: float) -> bool:
        if expires_at == _NO_EXPIRY:
            return False
        return time.time() >= expires_at

    def _count_files(self) -> int:
        count = 0
        try:
            for shard in self._cache_dir.iterdir():
                if shard.is_dir():
                    for f in shard.iterdir():
                        if f.is_file() and not f.name.endswith(".tmp"):
                            count += 1
        except OSError:
            pass
        return count

    # --- Core CRUD ---

    def get(self, key: str, default: Any = None) -> Any:
        self._validate_key(key)
        result = self._read_entry(self._key_to_path(key))
        if result is None:
            self._stats.record_miss()
            return default
        expires_at, value = result
        if self._is_expired(expires_at):
            self._key_to_path(key).unlink(missing_ok=True)
            self._stats.record_eviction()
            self._stats.record_miss()
            return default
        self._stats.record_hit()
        return value

    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        self._validate_key(key)
        effective_ttl = ttl if ttl is not None else self._default_ttl
        now = time.time()
        expires_at = (now + effective_ttl) if effective_ttl is not None else _NO_EXPIRY
        self._write_entry(self._key_to_path(key), value, expires_at)
        self._stats.record_set()

    def delete(self, key: str) -> bool:
        self._validate_key(key)
        try:
            self._key_to_path(key).unlink()
            self._stats.record_delete()
            return True
        except FileNotFoundError:
            return False

    def exists(self, key: str) -> bool:
        self._validate_key(key)
        result = self._read_entry(self._key_to_path(key))
        if result is None:
            return False
        expires_at, _ = result
        if self._is_expired(expires_at):
            self._key_to_path(key).unlink(missing_ok=True)
            self._stats.record_eviction()
            return False
        return True

    def clear(self, namespace: Optional[str] = None) -> int:
        if namespace is not None:
            raise NotImplementedError(
                "FileCache does not support namespace-scoped clear. "
                "Use CacheNamespace wrapper for namespace isolation."
            )
        count = 0
        for shard in self._cache_dir.iterdir():
            if shard.is_dir():
                for f in shard.iterdir():
                    if f.is_file() and not f.name.endswith(".tmp"):
                        f.unlink()
                        count += 1
                try:
                    shard.rmdir()
                except OSError:
                    pass
        return count

    # --- Stats ---

    def get_stats(self) -> CacheStats:
        return self._stats.snapshot(total_items=self._count_files())

    def disconnect(self) -> None:
        pass
